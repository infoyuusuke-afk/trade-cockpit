﻿AI Cockpit One-Click Starter
==============================

使い方
------

1. このフォルダ一式を C:\AI_Cockpit にコピーしてください。

2. 現在使っているファイルを次の場所へ入れます。

   C:\AI_Cockpit\Excel\
       MS2 RSS用の Excel ファイル

   C:\AI_Cockpit\Collector\
       Collector の .ps1 ファイル

   C:\AI_Cockpit\Cockpit\
       AI Cockpit の .html ファイル

3. デスクトップに
   START_AI_COCKPIT.cmd
   のショートカットを作ります。

4. 毎朝は
   START_AI_COCKPIT.cmd
   をダブルクリックするだけです。

最新版の選び方
--------------
各フォルダ内で「最終更新日時」が一番新しいファイルを自動選択します。

ただし次の文字をファイル名に含むものは自動起動から除外します。

_TEST
_BACKUP
_OLD
_DEV

例:
AI_Cockpit_MS2_LIVE_20260919.html       -> 対象
AI_Cockpit_MS2_LIVE_TEST.html           -> 除外

起動順
------
1. MarketSpeed II
2. 最新 MS2 RSS Excel
3. 最新 Collector
4. 127.0.0.1:28580 の応答確認
5. 最新 AI Cockpit HTML
6. Style-Bert-VITS2 App.bat

安全動作
--------
Collector が 30 秒以内に 127.0.0.1:28580 で応答しない場合、
AI Cockpit HTML は開かず停止します。

MarketSpeed II が見つからない場合も停止します。
その場合は MarketSpeed II を手動起動・ログイン後、
START_AI_COCKPIT.cmd をもう一度実行してください。

SBV2 の標準パス:
C:\sbv2\Style-Bert-VITS2\App.bat

ログ:
C:\AI_Cockpit\Logs\startup_YYYYMMDD_HHMMSS.log

注意
----
このランチャーは MarketSpeed II のログイン操作自体や、
RSS の接続状態そのものを保証するものではありません。
取引前に MarketSpeed II / Excel RSS / Cockpit の更新時刻を画面で確認してください。
