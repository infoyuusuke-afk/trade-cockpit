﻿@echo off
setlocal
cd /d "%~dp0"

title AI Cockpit Launcher
chcp 65001 >nul

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0START_AI_COCKPIT.ps1"

echo.
echo ========================================
echo  Press any key to close this window.
echo ========================================
pause >nul
endlocal
