﻿#requires -version 5.1
<#
AI Cockpit One-Click Launcher
- MarketSpeed II
- latest MS2 RSS Excel workbook
- latest Collector
- Collector port check (127.0.0.1:28580)
- latest AI Cockpit HTML
- Style-Bert-VITS2 App.bat
- logs
#>

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"

# ------------------------------------------------------------
# Basic paths
# ------------------------------------------------------------
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$ExcelDir = Join-Path $Root "Excel"
$CollectorDir = Join-Path $Root "Collector"
$CockpitDir = Join-Path $Root "Cockpit"
$LogDir = Join-Path $Root "Logs"
$BackupDir = Join-Path $Root "Backup"

$CollectorHost = "127.0.0.1"
$CollectorPort = 28580
$SbV2Bat = "C:\sbv2\Style-Bert-VITS2\App.bat"

$ExcludeRegex = '(?i)(_TEST|_BACKUP|_OLD|_DEV)'
$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$LogFile = Join-Path $LogDir ("startup_{0}.log" -f $Timestamp)

New-Item -ItemType Directory -Force -Path $ExcelDir, $CollectorDir, $CockpitDir, $LogDir, $BackupDir | Out-Null

function Write-Log {
    param(
        [Parameter(Mandatory=$true)][string]$Message,
        [ValidateSet("INFO","OK","WARN","ERROR")][string]$Level = "INFO"
    )
    $line = "[{0}] [{1}] {2}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Level, $Message
    Write-Host $line
    Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8
}

function Stop-WithError {
    param([string]$Message)
    Write-Log $Message "ERROR"
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Red
    Write-Host " AI COCKPIT STARTUP FAILED" -ForegroundColor Red
    Write-Host " $Message" -ForegroundColor Red
    Write-Host " Log: $LogFile" -ForegroundColor DarkGray
    Write-Host "========================================" -ForegroundColor Red
    exit 1
}

function Get-LatestFile {
    param(
        [Parameter(Mandatory=$true)][string]$Folder,
        [Parameter(Mandatory=$true)][string[]]$Patterns
    )

    $items = foreach ($pattern in $Patterns) {
        Get-ChildItem -LiteralPath $Folder -File -Filter $pattern -ErrorAction SilentlyContinue
    }

    $items = $items |
        Where-Object {
            $_.Name -notmatch $ExcludeRegex -and
            $_.Name -notlike "~$*"
        } |
        Sort-Object -Property `
            @{Expression = { $_.LastWriteTime }; Descending = $true}, `
            @{Expression = { $_.Name }; Descending = $true}

    return $items | Select-Object -First 1
}

function Test-TcpPort {
    param(
        [string]$ComputerName,
        [int]$Port,
        [int]$TimeoutMs = 750
    )
    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $async = $client.BeginConnect($ComputerName, $Port, $null, $null)
        if (-not $async.AsyncWaitHandle.WaitOne($TimeoutMs, $false)) {
            return $false
        }
        $client.EndConnect($async)
        return $true
    } catch {
        return $false
    } finally {
        $client.Close()
    }
}

function Find-MarketSpeedExecutable {
    $candidates = @(
        "$env:ProgramFiles\Rakuten Securities\MARKETSPEED II\MARKETSPEED2.exe",
        "${env:ProgramFiles(x86)}\Rakuten Securities\MARKETSPEED II\MARKETSPEED2.exe",
        "$env:LOCALAPPDATA\Rakuten Securities\MARKETSPEED II\MARKETSPEED2.exe",
        "$env:LOCALAPPDATA\Programs\Rakuten Securities\MARKETSPEED II\MARKETSPEED2.exe",
        "$env:ProgramFiles\Rakuten Securities\MarketSpeed2\MarketSpeed2.exe",
        "${env:ProgramFiles(x86)}\Rakuten Securities\MarketSpeed2\MarketSpeed2.exe"
    ) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }

    $candidates = @($candidates)
    if ($candidates.Count -gt 0) {
        return $candidates[0]
    }

    # Search Start Menu shortcuts and resolve target when possible.
    $shortcutRoots = @(
        "$env:APPDATA\Microsoft\Windows\Start Menu\Programs",
        "$env:ProgramData\Microsoft\Windows\Start Menu\Programs"
    )

    $shell = New-Object -ComObject WScript.Shell
    foreach ($shortcutRoot in $shortcutRoots) {
        if (-not (Test-Path -LiteralPath $shortcutRoot)) { continue }
        $links = Get-ChildItem -LiteralPath $shortcutRoot -Recurse -File -Filter "*.lnk" -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -match '(?i)(MARKETSPEED|マーケットスピード)' }
        foreach ($link in $links) {
            try {
                $target = $shell.CreateShortcut($link.FullName).TargetPath
                if ($target -and (Test-Path -LiteralPath $target)) {
                    return $target
                }
            } catch {}
        }
    }

    return $null
}

function Start-MarketSpeed {
    # Common process-name variations.
    $running = Get-Process -ErrorAction SilentlyContinue |
        Where-Object { $_.ProcessName -match '(?i)(MarketSpeed|MARKETSPEED|MarketSpeed2|Rakuten)' } |
        Select-Object -First 1

    if ($running) {
        Write-Log ("MarketSpeed II already running: PID {0}, {1}" -f $running.Id, $running.ProcessName) "OK"
        return
    }

    $exe = Find-MarketSpeedExecutable
    if (-not $exe) {
        Stop-WithError "MarketSpeed II was not found. Start MarketSpeed II manually, log in, then run this launcher again."
    }

    Write-Log "Starting MarketSpeed II: $exe"
    Start-Process -FilePath $exe | Out-Null
    Start-Sleep -Seconds 3

    $runningAfter = Get-Process -ErrorAction SilentlyContinue |
        Where-Object { $_.ProcessName -match '(?i)(MarketSpeed|MARKETSPEED|MarketSpeed2|Rakuten)' } |
        Select-Object -First 1

    if ($runningAfter) {
        Write-Log ("MarketSpeed II started: PID {0}" -f $runningAfter.Id) "OK"
    } else {
        Write-Log "MarketSpeed II launch command was sent. Login screen may still be opening." "WARN"
    }
}

function Start-LatestExcel {
    $latest = Get-LatestFile -Folder $ExcelDir -Patterns @("*RSS*.xlsx", "*Live*Signals*.xlsx", "*.xlsm", "*.xlsx")
    if (-not $latest) {
        Stop-WithError "No RSS Excel workbook was found in: $ExcelDir"
    }

    Write-Log ("Latest Excel: {0} / Modified {1}" -f $latest.FullName, $latest.LastWriteTime)

    # Avoid opening the exact same workbook twice when Excel already has it open.
    $alreadyOpen = $false
    try {
        $excel = [Runtime.InteropServices.Marshal]::GetActiveObject("Excel.Application")
        foreach ($wb in $excel.Workbooks) {
            if ($wb.FullName -eq $latest.FullName) {
                $alreadyOpen = $true
                break
            }
        }
    } catch {}

    if ($alreadyOpen) {
        Write-Log "Latest Excel workbook is already open." "OK"
    } else {
        Start-Process -FilePath $latest.FullName | Out-Null
        Write-Log "Excel workbook start command sent." "OK"
        Start-Sleep -Seconds 2
    }

    return $latest
}

function Start-LatestCollector {
    $latest = Get-LatestFile -Folder $CollectorDir -Patterns @("*Collector*.ps1", "*.ps1")
    if (-not $latest) {
        Stop-WithError "No Collector PowerShell file was found in: $CollectorDir"
    }

    Write-Log ("Latest Collector: {0} / Modified {1}" -f $latest.FullName, $latest.LastWriteTime)

    if (Test-TcpPort -ComputerName $CollectorHost -Port $CollectorPort) {
        Write-Log ("Collector port {0}:{1} already responding. Collector will not be started twice." -f $CollectorHost, $CollectorPort) "OK"
        return $latest
    }

    $collectorArgs = "-NoLogo -NoProfile -ExecutionPolicy Bypass -File `"$($latest.FullName)`""
    Start-Process -FilePath "powershell.exe" -ArgumentList $collectorArgs -WorkingDirectory $CollectorDir | Out-Null
    Write-Log "Collector start command sent."

    $deadline = (Get-Date).AddSeconds(30)
    while ((Get-Date) -lt $deadline) {
        if (Test-TcpPort -ComputerName $CollectorHost -Port $CollectorPort) {
            Write-Log ("Collector port check PASS: {0}:{1}" -f $CollectorHost, $CollectorPort) "OK"
            return $latest
        }
        Start-Sleep -Milliseconds 750
    }

    Stop-WithError ("Collector did not respond on {0}:{1} within 30 seconds. AI Cockpit was NOT opened for safety." -f $CollectorHost, $CollectorPort)
}

function Start-LatestCockpit {
    $latest = Get-LatestFile -Folder $CockpitDir -Patterns @("AI_Cockpit*.html", "*Cockpit*.html", "*.html")
    if (-not $latest) {
        Stop-WithError "No AI Cockpit HTML file was found in: $CockpitDir"
    }

    Write-Log ("Latest Cockpit HTML: {0} / Modified {1}" -f $latest.FullName, $latest.LastWriteTime)
    Start-Process -FilePath $latest.FullName | Out-Null
    Write-Log "AI Cockpit opened." "OK"
    return $latest
}

function Start-SBV2 {
    if (-not (Test-Path -LiteralPath $SbV2Bat)) {
        Write-Log "SBV2 App.bat was not found: $SbV2Bat. Voice startup skipped." "WARN"
        return $false
    }

    # Prevent double startup if a local server is already listening on the common web UI port.
    if (Test-TcpPort -ComputerName "127.0.0.1" -Port 7860) {
        Write-Log "SBV2 appears to be already running on port 7860." "OK"
        return $true
    }

    Start-Process -FilePath "cmd.exe" -ArgumentList "/c `"$SbV2Bat`"" -WorkingDirectory (Split-Path -Parent $SbV2Bat) | Out-Null
    Write-Log "SBV2 App.bat start command sent." "OK"
    return $true
}

# ------------------------------------------------------------
# Main
# ------------------------------------------------------------
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host " AI COCKPIT ONE-CLICK STARTUP" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Log "Startup begins. Root: $Root"

Start-MarketSpeed
$excelFile = Start-LatestExcel
$collectorFile = Start-LatestCollector
$cockpitFile = Start-LatestCockpit
$sbv2 = Start-SBV2

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host " AI COCKPIT STARTUP COMPLETE" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host "MarketSpeed II : OK"
Write-Host ("MS2 RSS Excel  : OK  [{0}]" -f $excelFile.Name)
Write-Host ("Collector      : OK  [{0}]" -f $collectorFile.Name)
Write-Host ("Port 28580     : OK")
Write-Host ("AI Cockpit     : OK  [{0}]" -f $cockpitFile.Name)
if ($sbv2) {
    Write-Host "SBV2 Voice     : OK / start command sent"
} else {
    Write-Host "SBV2 Voice     : SKIPPED"
}
Write-Host "========================================"
Write-Host ("Log: {0}" -f $LogFile) -ForegroundColor DarkGray
Write-Host ""
Write-Host "MarketSpeed II login/RSS connection must be confirmed on screen before trading." -ForegroundColor Yellow
Write-Host "If the Cockpit displays a stale-data warning, do not use it for trading decisions." -ForegroundColor Yellow

Write-Log "Startup sequence completed." "OK"
